<?php
    // Database configuration
    $db_hostname = "com.mysql.cj.jdbc.Driver";
    $db_username = "root";
    $db_password = "";
    $db_name = "tour";

    // Create a connection
    $conn = mysqli_connect($db_hostname, $db_username, $db_password, $db_name);

    // Check the connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Sanitize user inputs
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $subject = mysqli_real_escape_string($conn, $_POST['subject']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    // Use a prepared statement to prevent SQL injection
    $sql = "INSERT INTO contact (Name, Email, Phone, Subject, Message) VALUES (?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "sssss", $name, $email, $phone, $subject, $message);

        if (mysqli_stmt_execute($stmt)) {
            echo "We will contact you soon";
        } else {
            echo "Error: " . mysqli_stmt_error($stmt);
        }

        // Close the statement
        mysqli_stmt_close($stmt);
    } else {
        echo "Error preparing statement: " . mysqli_error($conn);
    }

    // Close the connection
    mysqli_close($conn);
?>
